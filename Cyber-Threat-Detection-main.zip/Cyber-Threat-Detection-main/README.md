# Real-Time Cyber Threat Detection Using Advanced Data Structures

## About the Project
This project detects suspicious network activities using Python and Advanced Data Structures. It stores detected threats in a MySQL database and generates security alerts and reports.

## Technologies Used
- Python
- MySQL
- Advanced Data Structures

## Project Modules
1. Network Traffic Monitoring
2. Advanced Data Structures
3. Cyber Threat Detection
4. Database Management
5. Alert Management and Reporting

## Threats Detected
- Multiple Failed Login Attempts
- Port Scanning

## How to Run

1. Install Python and MySQL.
2. Clone or download this repository.
3. Install required packages:

   pip install -r requirements.txt

4. Open MySQL Workbench and run the SQL file:
   database/cyber_threat_db.sql

5. Create a `.env` file in the project folder using `.env.example`.
6. Enter your MySQL credentials in `.env`.
7. Run the project:

   python main.py

## Note
This project currently uses simulated network events for demonstration. It is an academic prototype, not a live network monitoring system.